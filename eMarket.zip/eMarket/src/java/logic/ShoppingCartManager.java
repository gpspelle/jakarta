/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Product;
import model.ShoppingCartItem;

/**
 *
 * @author pellegrino
 */
@ManagedBean
@SessionScoped
public class ShoppingCartManager implements Serializable {
    private ArrayList<ShoppingCartItem> shoppingCart;
    private Product prodToAdd;
    private ShoppingCartItem prodToRemove;
    
    public ShoppingCartManager() {
        this.shoppingCart = new ArrayList<>( );
    }

    /**
     * @return the shoppingCart
     */
    public ArrayList<ShoppingCartItem> getShoppingCart() {
        return shoppingCart;
    }

    public void addToCart() {
        ShoppingCartItem shoppingCartItem = new ShoppingCartItem(prodToAdd.getId(), 1, prodToAdd); 
        this.shoppingCart.add(shoppingCartItem);
    }
    
    public void removeFromCart() {
       this.shoppingCart.remove(this.getProdToRemove());
    }
    
    /**
     * @param shoppingCart the shoppingCart to set
     */
    public void setShoppingCart(ArrayList<ShoppingCartItem> shoppingCart) {
        this.shoppingCart = shoppingCart;
    }

    /**
     * @return the prodToAdd
     */
    public Product getProdToAdd() {
        return prodToAdd;
    }

    /**
     * @param prodToAdd the prodToAdd to set
     */
    public void setProdToAdd(Product prodToAdd) {
        this.prodToAdd = prodToAdd;
    }

    /**
     * @return the prodToRemove
     */
    public ShoppingCartItem getProdToRemove() {
        return prodToRemove;
    }

    /**
     * @param prodToRemove the prodToRemove to set
     */
    public void setProdToRemove(ShoppingCartItem prodToRemove) {
        this.prodToRemove = prodToRemove;
    }
    
    
    
    
}
