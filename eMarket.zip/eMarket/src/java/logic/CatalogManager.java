/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import java.io.Serializable;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import model.Product;


import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;

/**
 *
 * @author pellegrino
 */
@ManagedBean
@ApplicationScoped
public class CatalogManager implements Serializable {
    private ArrayList<Product> products;
    private int productId;
    private String productName;
    private double productPrice;
    
    public CatalogManager() {
        this.products = new ArrayList<>( );
    }
    
    @PostConstruct
    public void initCatalog() {
        this.products.add(new Product(1, "Apple watch", 500));
        this.products.add(new Product(2, "Macbook air", 1000));
        this.products.add(new Product(3, "Samsung Galaxy S20", 750));
    }
    
    public ArrayList<Product> getProducts() {
        return products;
    }
    
    public void createProduct() {
        boolean add;
        add = this.products.add(new Product(this.getProductId(), this.getProductName(), this.getProductPrice()));
    }
    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }
    
    public int getProductId() {
        return productId;
    }
    
    public void setProductId(int productId) {
        this.productId = productId;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public double getProductPrice() {
        return productPrice;
    }
    
    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
   
}
