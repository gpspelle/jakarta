/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author pellegrino
 */
public class ShoppingCartItem implements Serializable {
    private int id;
    private int amount;
    private Product product;

    public ShoppingCartItem() {
        
    }
    
    /**
     *
     * @param id
     * @param amount
     * @param product
     */
    public ShoppingCartItem(int id, int amount, Product product) {
        this.id = id;
        this.amount = amount;
        this.product = product;
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the amount
     */
    public int getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(int amount) {
        this.amount = amount;
    }

    /**
     * @return the product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(Product product) {
        this.product = product;
    }
    
}
